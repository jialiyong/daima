<?php
/**
 *-------------------
 * User: cymsummer
 * Date: 2017/6/9
 *-------------------
 * Time: 20:26
 */
class QiniuConfig{

    // 需要填写你的 Access Key 和 Secret Key
    const accessKey = 'Ju0OhRR5g3vdCSD2Gbd1DZUfiE1h9wdl6iiPqfXa';

    const secretKey = 'a4biVAouc2ku_wT--zxBRwdE_IWCj20cSRDCbXEM';

    //图片的域名
    const domain ='http://7xrxhu.com1.z0.glb.clouddn.com';

    // 要上传的空间
    const bucket = 'testonly';
}
?>