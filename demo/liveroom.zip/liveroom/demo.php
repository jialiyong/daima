<?php
file_put_contents(date("Y-m-d") . "exit", json_encode("222") . "\n", FILE_APPEND);