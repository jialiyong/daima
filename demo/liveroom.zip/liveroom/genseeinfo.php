<?php

//获取展示自有参数
$gensee_url =   $_GET['gensee_url'];
$ownerid    =   $_GET['tags'];
$authcode   =   $_GET['gensee_token'];
$k          =   $_GET['k'];
$uid        =   $_GET['uid'];

?>
